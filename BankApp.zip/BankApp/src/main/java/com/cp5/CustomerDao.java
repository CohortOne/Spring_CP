package com.cp5;

import java.util.List;

public interface CustomerDao {
	public List<Customer> getAllCustomers();
}
