package com.CP5;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LabEmpController {

//	public LabEmpController() {
//		// TODO Auto-generated constructor stub
//	}
	
	@Autowired
	private LabEmpDao labEmpDao;
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
//		model.addAttribute("listLabEmps", labEmpDao.getAllLabEmps());
//		return "index";
		return findPaginated(1, "empId", "ASC", model);
	}

	@GetMapping("/page/{pageNo}")
	private String findPaginated(@PathVariable(value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			Model model) {
		// TODO Auto-generated method stub
//		return null;
		int pageSize = 10;
		Page <LabEmp> page = labEmpDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List <LabEmp> listLabEmps = page.getContent();
		model.addAttribute("listLabEmps", listLabEmps);
		
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		
		return "index";
	}
	
	@GetMapping("/showNewLabEmpForm")
	public String showNewLabEmpForm(Model model) {
		LabEmp labEmp =new LabEmp();
		model.addAttribute("labEmp", labEmp);
		return "new_labEmp";
	}
	
	@PostMapping("/saveLabEmp")
	public String saveLabEmp(@Valid @ModelAttribute("labEmp") LabEmp labEmp, BindingResult bindingResult ) {
		//save LabEmp to database
		if(bindingResult.hasErrors())
			return "new_labEmp";
		
		labEmpDao.saveLabEmp(labEmp);
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{empId}")
	public String showFormForUpdate(@PathVariable(value = "empId") long empId, Model model) {
		// Get labEmp from the Service 
		LabEmp labEmp = labEmpDao.getLabEmpById(empId);
		
		// set labEmp as a model attribute to pre-populate the form 
		model.addAttribute("labEmp", labEmp);
		return "update_labEmp";
	}
	
	@GetMapping("/deleteLabEmp/{empId}")
	public String deleteLabEmp(@PathVariable (value = "empId") long empId) {
	 // call delete labEmp method 
	 this.labEmpDao.deleteLabEmpById(empId);
	 return "redirect:/";
	}
	
	
	
	
}//-end public class LabEmpController
