package com.CP5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="LABEMP")
public class LabEmp {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EMPID" )
	private long empId;
	
	@Size (min = 1, max = 30)
//	@NotNull
	@Column(name = "FIRSTNAME") 
	private String firstName;
	
	@Size (min = 1, max = 30)
	@NotNull
	@Column(name = "LASTNAME") 
	private String lastName;
	
	@Size (min = 8, max = 30)
	@NotNull
	@Column(name = "EMAIL")
	private String email;
	
//	@NotNull
	@Size (min = 6, max = 20)
	@Column(name = "PHONENUM")
	private String phoneNum;
	
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "HIREDATE")  
	private LocalDate hireDate;
	
	@NotNull
	@Size (min = 1, max = 15)
	@Column(name = "JOBID")
	private String jobID;
	
	@Column(name = "SALARY")
	private double salary;
	
	@Column(name = "COMMISSIONPERCENT")
	private double commissionPercent;
	
	@Column(name = "MANAGERID")
	private int managerId;
	
	@Column(name = "DEPARTMENTID")
	private int departmentId;

	
	//Getter and Setter
	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public String getJobID() {
		return jobID;
	}

	public void setJobID(String jobID) {
		this.jobID = jobID;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getCommissionPercent() {
		return commissionPercent;
	}

	public void setCommissionPercent(double commissionPercent) {
		this.commissionPercent = commissionPercent;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	
	
//	public LabEmp() {
//		// TODO Auto-generated constructor stub
//	}

}//-end public class LabEmp {
