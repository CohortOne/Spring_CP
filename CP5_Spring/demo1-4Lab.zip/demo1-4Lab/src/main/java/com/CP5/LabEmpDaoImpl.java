package com.CP5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class LabEmpDaoImpl implements LabEmpDao {
	
	@Autowired
	private LabEmpRepository labEmpRepository;
	
//	public LabEmpDaoImpl() {
//		// TODO Auto-generated constructor stub
//	}

	@Override
	public List<LabEmp> getAllLabEmps() {
		// TODO Auto-generated method stub
//		return null;
		
		List<LabEmp> list = labEmpRepository.findAll();
		System.out.println("**********************************");
		System.out.println("Employees List Size " + list.size());
		System.out.println("**********************************");
		return list;
		
	}

	@Override
	public void saveLabEmp(LabEmp labEmp) {
		// TODO Auto-generated method stub
		labEmpRepository.save(labEmp);
	}

	@Override
	public LabEmp getLabEmpById(long empId) {
		// TODO Auto-generated method stub
//		return null;
		
		Optional <LabEmp> optional = labEmpRepository.findById(empId);
		LabEmp labEmp = null;
		
		if(optional.isPresent())
			labEmp = optional.get();
		else
			throw new RuntimeException(" Employee not found for id :: " + empId);
		
		return labEmp;
		
	}

	@Override
	public void deleteLabEmpById(long empId) {
		// TODO Auto-generated method stub
		labEmpRepository.deleteById(empId);
	}

	@Override
	public Page<LabEmp> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		// TODO Auto-generated method stub
//		return null;
		
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? 
				Sort.by(sortField).ascending() : Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo -1, pageSize, sort);
		return labEmpRepository.findAll(pageable);
		
	}

}
