package com.CP5;

import java.util.List;

import org.springframework.data.domain.Page;


public interface LabEmpDao {
	public List <LabEmp> getAllLabEmps();
	public void saveLabEmp(LabEmp labEmp);
	public LabEmp getLabEmpById(long empId);
	public void deleteLabEmpById(long empId);
	
	public Page <LabEmp> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);

}
