package com.rj;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class accountController {
	
	@Autowired
	private AccountDao accountDao;
	
	
	@GetMapping("/")
	public String displayHomePage(Model model) {
//		model.addAttribute("listAccounts", accountDao.getAll());
		return findPaginated(1, "accountId", "ASC", model);
	}
	
	@GetMapping("/showNewAccountForm")
	public String displayNewAccountForm(Model model) {
		Account account = new Account();
		model.addAttribute("account", account);
		return "new_account";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccount(@Valid @ModelAttribute("account") Account account, BindingResult bindingResult) {
		
		if(bindingResult.hasErrors())
			return "new_account";
		
		account.setDateCreated(LocalDateTime.now());
		accountDao.saveAccount(account);
		return "redirect:/";
	}
	
	@GetMapping("/page/{pageNo}")
	private String findPaginated(@PathVariable(value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			Model model) {
		
		int pageSize = 5;
		Page <Account> page = accountDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List <Account> listAccounts = page.getContent();
		model.addAttribute("listAccounts", listAccounts);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		return "index";
	}
	
//	@GetMapping("/showFormForUpdate/{accountId}")
//	public String showFormForUpdate(@PathVariable(value = "accountId") int accountId, Model model) {
//		 
//		Account account = accountDao.getAccountbyId(accountId); 
//		model.addAttribute("account", account);
//		return "update_account";
//	}
	
	@GetMapping("/deleteAccount/{accountId}")
	public String deleteAccount(@PathVariable (value = "accountId") int accountId) {
	 // call delete employee method 
	 this.accountDao.deleteAccountById(accountId);
	 return "redirect:/";
	}
}
