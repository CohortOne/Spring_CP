package com.rj;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class AccountDaoImpl implements AccountDao {

	@Autowired
	AccountRepository accountRespository;
	
	public AccountDaoImpl() {
	}

	@Override
	public List<Account> getAll() {
		return accountRespository.findAll();
	}

	@Override
	public Account getAccountbyId(int accountId) {
		Optional<Account> optional =  accountRespository.findById(accountId);
		Account account = new Account();
		if(optional.isPresent()) {
			account = optional.get();
		}
		else
			throw new RuntimeException(" Account not found for id :: " + accountId);
		
		return account;
		
		
	}

	@Override
	public void saveAccount(Account account) {
		accountRespository.save(account);

	}

	@Override
	public void deleteAccountById(int accountId) {
		accountRespository.deleteById(accountId);

	}
	

	@Override
	public Page<Account> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo -1, pageSize, sort);
		return accountRespository.findAll(pageable);
	}

}
