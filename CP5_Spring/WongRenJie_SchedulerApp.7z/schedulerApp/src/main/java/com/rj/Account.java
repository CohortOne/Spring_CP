package com.rj;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "ACCOUNT")
public class Account {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ACCOUNTID")
	private int accountId;
	
	@Column(name="USERNAME")
	@NotNull
	@Size(min = 8,max = 30)
	private String username;
	
	@Column(name="PASSCODE")
	@NotNull
	@Size(min = 8,max = 30)
	private String password;
	
	@Column(name="EMAIL")
	@NotNull
	@Size(max = 30)
	@Email
	private String email;
	
	@NotNull
	@Column(name="MOBILENO")
	@Min(value = 0)
	@Max(value = 99999999)
//	@Size(min = 8, max = 13)
	private Integer mobileNo;
	
	@Column(name="DOB")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull
	private LocalDate dob;
	
	@Column(name="DATECREATED")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dateCreated;
	
	@Column(name="ISACTIVE")
	private Boolean isActive;
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Integer mobileNo) {
		this.mobileNo = mobileNo;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public LocalDateTime getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(LocalDateTime dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Boolean isActive() {
		return isActive;
	}
	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", username=" + username + ", password=" + password + ", email="
				+ email + ", mobileNo=" + mobileNo + ", dob=" + dob + ", dateCreated=" + dateCreated + ", isActive="
				+ isActive + "]";
	}
}
