package com.rj;

import java.util.List;

import org.springframework.data.domain.Page;


public interface AccountDao {

	
	public List<Account> getAll(); 
	public Account getAccountbyId(int accountID);
	public void saveAccount(Account account);
	public void deleteAccountById(int accountID);
	public Page <Account> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
}