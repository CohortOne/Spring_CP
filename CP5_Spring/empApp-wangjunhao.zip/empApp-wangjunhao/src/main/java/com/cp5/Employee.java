package com.cp5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import com.sun.istack.NotNull;


	@Entity
	@Table(name= "Employee")
	public class Employee {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long empId;
		
		@Column(name = "EMPNAME")  
		@Size (min = 8, max = 30)
		@NotNull
		private String empName;
		
		@Column(name = "EMAIL")
		@Size (min = 8, max = 30)
		@NotNull
		@Email(message = " Should be a valid Email Address")
		private String email;
		
		@NotNull
		@Column(name = "HIRE_DATE")  
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate hd;
		
		@Column(name = "ISACTIVE")
		private boolean isActive;
		
		@NotNull
		@Column(name = "PHONENO")
		@Size (min = 8, max = 13)
		private String phoneNo;
		
		@NotNull
		@Column(name = "SALARY")
		private String salary;
		
		
		public long getEmpId() {
			return empId;
		}


		public void setEmpId(long empId) {
			this.empId = empId;
		}


		public String getEmpName() {
			return empName;
		}


		public void setEmpName(String empName) {
			this.empName = empName;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public LocalDate getHd() {
			return hd;
		}


		public void setHd(LocalDate hd) {
			this.hd = hd;
		}


		public boolean getIsActive() {
			return isActive;
		}


		public void setIsActive(boolean isActive) {
			this.isActive = isActive;
		}


		public String getPhoneNo() {
			return phoneNo;
		}


		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}


		public String getSalary() {
			return salary;
		}


		public void setSalary(String salary) {
			this.salary = salary;
		}


		public int getDeptId() {
			return deptId;
		}


		public void setDeptId(int deptId) {
			this.deptId = deptId;
		}


		@Column(name = "DEPTID")	
		private int deptId;
}
