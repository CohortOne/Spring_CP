package com.cp5;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmployeeController 
 {
	@Autowired
	private EmployeeDao employeeDao;
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		
		//model.addAttribute("listCustomers",employeeDao.getAllCustomer());
		//return "index";
		return findPaginated(1,"empId", "ASC" ,model);
	}
	@GetMapping("/page/{pageNo}")
	private String findPaginated(@PathVariable(value = "pageNo") int pageNo, @RequestParam("sortField")String sortField,
			@RequestParam("sortDirection")String sortDirection, Model model) {
		
		int pageSize = 5;
		Page <Employee> page = employeeDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List <Employee> listEmployee = page.getContent();
		model.addAttribute("listEmployee", listEmployee);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		return "index";
	}

	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "new_employee";
	}
	@PostMapping("/saveEmployee")
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee, BindingResult bindingResult) {
        // save employee to database
		
		if(bindingResult.hasErrors())
			return "new_employee";
		
		employeeDao.saveEmployee(employee);
		return "redirect:/";
	}

	@GetMapping("/showFormForUpdate/{empId}")
	public String showFormForUpdate(@PathVariable(value = "empId") long empId, Model model) {
		// Get Employee from the Service 
		Employee employee = employeeDao.getEmployeeById(empId);
		
		// set employee as a model attribute to pre-populate the form 
		model.addAttribute("employee", employee);
		return "update_employee";
	}
	@GetMapping("/deleteEmployee/{empId}")
	public String deleteEmployee(@PathVariable (value = "empId") long empId) {
	 // call delete employee method 
	 this.employeeDao.deleteEmployeeById(empId);
	 return "redirect:/";
	}



}

