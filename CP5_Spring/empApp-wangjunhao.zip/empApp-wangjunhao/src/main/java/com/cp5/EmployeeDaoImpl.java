package com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployee() {
		
		return employeeRepository.findAll();
		
	}

	@Override
	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
		
	}
	@Override
	public void deleteEmployeeById(long empId) {
		employeeRepository.deleteById(empId);
	}
	@Override
	public Employee getEmployeeById(long empId) {
		
		Optional <Employee> optional =employeeRepository.findById(empId);
		Employee employee = null;
		
		if(optional.isPresent())
			employee = optional.get();
		else
			throw new RuntimeException(" employee not found for id :: " + empId);
		
		return employee;		
	}
	@Override
	public Page<Employee> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo -1, pageSize, sort);
		return employeeRepository.findAll(pageable);
	}

	

	


	


}