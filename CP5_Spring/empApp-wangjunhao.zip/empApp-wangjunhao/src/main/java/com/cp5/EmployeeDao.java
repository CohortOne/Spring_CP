package com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

public interface EmployeeDao {
	public List<Employee> getAllEmployee();
	public void saveEmployee(Employee employee);
	public Employee getEmployeeById(long empId);
	public void deleteEmployeeById(long empId);
	public Page <Employee> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
}


