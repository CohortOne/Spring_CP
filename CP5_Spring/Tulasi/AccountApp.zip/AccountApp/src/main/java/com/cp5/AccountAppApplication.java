package com.cp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountAppApplication.class, args);
	}

}
