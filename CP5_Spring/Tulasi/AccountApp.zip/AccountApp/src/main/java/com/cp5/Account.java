package com.cp5;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import com.sun.istack.NotNull;

@Entity
@Table(name = "AccountDetails")
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ACCNO")
	private long accNo;
	
	@Column(name = "CUSTUIN")
	@NotNull
	@Size(min = 8, max =15 )
	private String custUIN;
	
	
	@Column(name = "ACCTYPE")
	@NotNull
	@Size(min = 5, max = 30, message ="Account Type is needed")
	private String accType;
   
	@Column(name = "ACCBAL")
	@NotNull
	@Min(value = 500, message = "minimum Account balance is 500")
    private long accBal;
	
	@Column(name = "MINBAL")
	@NotNull
	@Min(value = 500, message = "minimum Account balance is 500")
    private long minBal;
	
	 @Column(name = "ISACTIVE")
	private boolean isActive;

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getCustUIN() {
		return custUIN;
	}

	public void setCustUIN(String custUIN) {
		this.custUIN = custUIN;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public long getAccBal() {
		return accBal;
	}

	public void setAccBal(long accBal) {
		this.accBal = accBal;
	}

	public long getMinBal() {
		return minBal;
	}

	public void setMinBal(long minBal) {
		this.minBal = minBal;
	}

	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}

}
