package com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

public interface VehicleDao {
	
	public List<Vehicle> getAllVehicle();
	public void saveVehicle(Vehicle vehicle);
	public Vehicle getVehicleById(String registrationNum);
	public void deleteVehicleById(String registrationNum);
	public Page <Vehicle> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);

}
