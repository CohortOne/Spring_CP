package com.cp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleRegistrationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleRegistrationAppApplication.class, args);
	}

}
