package com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class VehicleDaoImpl implements VehicleDao {

	@Autowired
	private VehicleRepository vehicleRepository;
	
	public VehicleDaoImpl() {}
	
	@Override
	public List<Vehicle> getAllVehicle() {
		return vehicleRepository.findAll();
	}

	@Override
	public void saveVehicle(Vehicle vehicle) {
		vehicleRepository.save(vehicle);

	}

	@Override
	public Vehicle getVehicleById(String registrationNum) {
		
		Optional <Vehicle> optional = vehicleRepository.findById(registrationNum);
		Vehicle vehicle = null;
		
		if (optional.isPresent())
			vehicle = optional.get();
		else
			throw new RuntimeException("Vehicle not found for License Number " + registrationNum);
		
		return vehicle;
	}

	@Override
	public void deleteVehicleById(String registrationNum) {
		vehicleRepository.deleteById(registrationNum);

	}

	@Override
	public Page<Vehicle> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		
		Pageable pageable = PageRequest.of(pageNo-1, pageSize, sort);
		return vehicleRepository.findAll(pageable);
	}

}
