package com.cp5;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class VehicleController {
	
	@Autowired
	private VehicleDao vehicleDao;

	@GetMapping("/")
	public String viewHomePage(Model model) {
		
//		model.addAttribute("listVehicles", vehicleDao.getAllVehicle());
		
		return findPaginated(1, "registrationNum", "ASC", model);
		
	}
	
	@GetMapping("/page/{pageNo}")
	private String findPaginated(@PathVariable(value = "pageNo") int pageNo,
									@RequestParam("sortField") String sortField,
									@RequestParam("sortDirection") String sortDirection,
									Model model) {
		
		int pageSize = 10; //x records per page
		Page <Vehicle> page = vehicleDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List <Vehicle> listVehicles = page.getContent();
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		return "index";
	}
	
	@GetMapping("/showNewVehicleForm")
	public String showNewVehicleForm(Model model) {
		
		Vehicle vehicle = new Vehicle();
		model.addAttribute("vehicle", vehicle);
		return "new_vehicle";
	}
	
	@PostMapping("/saveVehicle")
	public String saveVehicle(@Valid @ModelAttribute("vehicle")Vehicle vehicle, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors())
			return "new_vehicle";
		
		vehicleDao.saveVehicle(vehicle);				
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{registrationNum}")
	public String showFormForUpdate(@PathVariable(value = "registrationNum") String registrationNum, Model model) {
		// Get Vehicle from the Service 
		Vehicle vehicle = vehicleDao.getVehicleById(registrationNum);
		
		// set vehicle as a model attribute to pre-populate the form 
		model.addAttribute("vehicle", vehicle);
		return "update_vehicle";
	}
	
	@GetMapping("/deleteVehicle/{registrationNum}")
	public String deleteVehicle(@PathVariable (value = "registrationNum") String registrationNum) {
	 // call delete vehicle method 
	 this.vehicleDao.deleteVehicleById(registrationNum);
	 return "redirect:/";
	}
}
