package com.cp5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="VEHICLE")
public class Vehicle {
	
	@Id
	@Column(name="REGISTRATION_NUMBER")
	@Size(min=3, max=8)
	private String registrationNum;
	
	@NotNull
	@Column(name="VEH_BRAND")
	private String vehBrand;
	
	@NotNull
	@Column(name="VEH_MODEL")
	private String vehModel;
	
	@NotNull
	@Column(name="FUEL_TYPE")
	private String fuelType;
	
	@NotNull
	@Column(name="ENGINE_CAP")
	private int engineCap;
	
	@NotNull
	@Column(name="REGISTER_DATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate registerDate;
	
	@NotNull
	@Column(name="OWNER_NAME")
	private String ownerName;
	
	@NotNull
	@Column(name="NRIC")
	@Size(min=9, max=9)
	private String ownerNRIC;
	
	@NotNull
	@Column(name="ADDRESS")
	private String address;
	
	@NotNull
	@Column(name="PHONENO")
	private String phoneNo;

	public String getRegistrationNum() {
		return registrationNum;
	}

	public void setRegistrationNum(String registrationNum) {
		this.registrationNum = registrationNum;
	}

	public String getVehBrand() {
		return vehBrand;
	}

	public void setVehBrand(String vehBrand) {
		this.vehBrand = vehBrand;
	}

	public String getVehModel() {
		return vehModel;
	}

	public void setVehModel(String vehModel) {
		this.vehModel = vehModel;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public int getEngineCap() {
		return engineCap;
	}

	public void setEngineCap(int engineCap) {
		this.engineCap = engineCap;
	}

	public LocalDate getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(LocalDate registerDate) {
		this.registerDate = registerDate;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerNRIC() {
		return ownerNRIC;
	}

	public void setOwnerNRIC(String ownerNRIC) {
		this.ownerNRIC = ownerNRIC;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	
}	

