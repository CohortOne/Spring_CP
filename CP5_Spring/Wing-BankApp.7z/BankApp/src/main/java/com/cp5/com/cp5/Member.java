package com.cp5.com.cp5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity

@Table(name="Member")
public class Member {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "MEMID" )
		private long memId;

		@Column(name = "MEMNAME")  
		@Size (min = 8, max = 30)
		@NotNull
		private String memName;

		@NotNull
		@Column(name = "DOB")  
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate dob;
		
		@Column(name = "EMAIL")
		@Size (min = 8, max = 30)
		@NotNull
		@Email(message = " Should be a valid Email Address")
		private String email;

		
		@Column(name = "ISACTIVE")
		private boolean isActive;

		@NotNull
		@Column(name = "PHONENO")
		@Size (min = 8, max = 13)
		private String phoneNo;

		  
		public String getOccupation() {
			return occupation;
		}

		public void setOccupation(String occupation) {
			this.occupation = occupation;
		}

		@Size (min = 4, max = 20)
		@Column(name = "OCCUPATION") 
		private String occupation;
		 

		public long getMemId() {
			return memId;
		}

		public void setMemId(long memId) {
			this.memId = memId;
		}

		public String getMemName() {
			return memName;
		}

		public void setMemName(String memName) {
			this.memName = memName;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public LocalDate getDob() {
			return dob;
		}

		public void setDob(LocalDate dob) {
			this.dob = dob;
		}

		public boolean getIsActive() {
			return isActive;
		}

		public void setIsActive(boolean isActive) {
			this.isActive = isActive;
		}

		public String getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}

		/*
		 * public String getPassCode() { return passCode; }
		 * 
		 * public void setPassCode(String passCode) { this.passCode = passCode; }
		 */
		
		
		

}
