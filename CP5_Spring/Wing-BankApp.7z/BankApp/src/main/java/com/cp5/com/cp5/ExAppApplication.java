package com.cp5.com.cp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import com.cp5.BankAppApplication;

@SpringBootApplication
public class ExAppApplication {

			public static void main(String[] args) {
			SpringApplication.run(ExAppApplication.class, args);
		}

	}


