package com.cp5.com.cp5;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.cp5.Customer;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

}
