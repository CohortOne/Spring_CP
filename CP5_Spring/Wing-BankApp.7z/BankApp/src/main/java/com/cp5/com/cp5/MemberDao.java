package com.cp5.com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

//import com.cp5.com.cp5.Member;

public interface MemberDao {
	
	public List<Member> getAllMembers();
	public void saveMember(Member member);
	public Member getMemberById(long memId);
	public void deleteMemberById(long memId);
	public Page <Member> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
   

}
