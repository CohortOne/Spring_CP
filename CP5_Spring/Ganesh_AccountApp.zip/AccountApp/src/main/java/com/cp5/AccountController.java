package com.cp5;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@Autowired
	private AccountDao accountDao;
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("listAccounts", accountDao.getAllAccounts());
		return findPaginated(1, "accNo", "ASC", model);
	}
	
	@GetMapping("/page/{pageNo}")
	private String findPaginated(@PathVariable(value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, Model model) {
		
		int pageSize = 5;
		Page <Account> page = accountDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List<Account> listAccounts = page.getContent();
		model.addAttribute("listAccounts", listAccounts);	
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("DESC") ? "DESC" : "ASC");
		return "index";
	}

	@GetMapping("/showNewAccountForm")
	public String showNewAccountForm(Model model) {
		Account account =new Account();
		model.addAttribute("account", account);
		return "new_account";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccount(@Valid @ModelAttribute("account") Account account, BindingResult bindingResult) {
        // save employee to database
		
		if(bindingResult.hasErrors())
			return "new_account";
		
		accountDao.saveAccount(account);
		return "redirect:/";
	}

	@GetMapping("/showFormForUpdate/{accNo}")
	public String showFormForUpdate(@PathVariable(value = "accNo") long accNo, Model model) {
		
		//dropdown list
//		List<String> accountType = null;
//		
//		{
//			accountType = new ArrayList<>();
//			accountType.add("Checking");
//			accountType.add("Savings");
//			accountType.add("Fixed Deposit");
//			
//			
//		}		
//		
		// Get Employee from the Service 
		Account account = accountDao.getAccountById(accNo);
		
		// set employee as a model attribute to pre-populate the form 
		model.addAttribute("account", account);
	//	model.addAttribute("accountType", accountType);
		return "update_account";
	}
	
	@GetMapping("/deleteAccount/{accNo}")
	public String deleteAccount(@PathVariable (value = "accNo") long accNo) {
	 // call delete employee method 
	 this.accountDao.deleteAccountById(accNo);
	 return "redirect:/";
	}

}
