package com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class AccountDaoImpl implements AccountDao{

	@Autowired
	private AccountRepository accountRepository;
	
	@Override
	public List<Account> getAllAccounts() {
		List<Account> list = accountRepository.findAll();
		System.out.println("**********************************");
		System.out.println("Account List Size " + list.size());
		System.out.println("**********************************");
		return list;
	}
	
	@Override
	public void saveAccount(Account account) {
		accountRepository.save(account);
	}
	
	@Override
	public Account getAccountById(long custId) {
		
		Optional <Account> optional = accountRepository.findById(custId);
		Account account = null;
		
		if(optional.isPresent())
			account = optional.get();
		else
			throw new RuntimeException(" Account not found for id :: " + custId);
		
		return account;		
	}

	@Override
	public void deleteAccountById(long custId) {
		accountRepository.deleteById(custId);
	}

	
	@Override
	public Page<Account> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return accountRepository.findAll(pageable);
	}

}
