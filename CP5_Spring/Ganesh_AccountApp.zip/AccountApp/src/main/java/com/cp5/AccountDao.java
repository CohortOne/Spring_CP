package com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

public interface AccountDao  {
	public List<Account> getAllAccounts();
	public void saveAccount(Account account);
	public Account getAccountById(long custId);
	public void deleteAccountById(long custId);
	public Page <Account> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
}
