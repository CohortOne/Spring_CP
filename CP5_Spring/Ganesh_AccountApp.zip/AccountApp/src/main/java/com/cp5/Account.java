package com.cp5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "Account")

public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column (name = "ACCOUNT_NO")
	private long accNo;
	
	@Column(name = "ACCOUNT_TYPE")
	@NotNull
	@Size (min = 5, max = 30)
	private String accType;
	
	
	@Column (name = "START_DATE")
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate startDate;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "CUST_NAME")  
	@Size (min = 8, max = 30)
	@NotNull
	private String custName;
	
	@NotNull
	@Size (min = 3, max = 3)
	@Column(name = "CURRENCY")
	private String baseCurrency;
	
	@Column (name = "BALANCE")
	private int balance;
	
	
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getBaseCurrency() {
		return baseCurrency;
	}
	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
}
