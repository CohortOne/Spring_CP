package com.cp5;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EntertainmentController {

	@Autowired
	private EntertainmentDao entDao;
	
	@RequestMapping("/")
	public String viewHomePage(Model model, @Param("keyword") String keyword) {
		return findPageinated(1, "showId", "ASC", model, keyword);
	}
	
	@GetMapping("/page/{pageNo}")
	private String findPageinated(@PathVariable(value="pageNo")int pageNo,
									@Param("sortField")String sortField, 
									@Param("sortDirection")String sortDirection, 
									Model model, 
									@Param("keyword")String keyword) {
		int pageSize = 5;
		Page<Entertainment> page = entDao.findPaginated(pageNo, pageSize, sortField, sortDirection, keyword);
		List<Entertainment> listShows = page.getContent();
		
		model.addAttribute("listShows", listShows);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		
		return "index";
	}
	
	@GetMapping("/showNewEntForm")
	public String showNewEntForm(Model model) {
		Entertainment entertainment = new Entertainment();
		model.addAttribute("entertainment", entertainment);
		return "new_entertainment";
	}
	
	@PostMapping("/saveEntertainment")
	public String saveEntertainment(@Valid @ModelAttribute("entertainment")Entertainment entertainment, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			System.out.println("Error" + bindingResult.getAllErrors());
			return "new_entertainment";
		}
		entDao.saveShow(entertainment);
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{showId}")
	public String showFormForUpdate(@PathVariable(value = "showId")long showId, Model model) {
		Entertainment entertainment = entDao.getShowById(showId);
		model.addAttribute("entertainment", entertainment);
		return "update_entertainment";
	}
	
	@GetMapping("/deleteEntertainment/{showId}")
	public String deleteEntertainment(@PathVariable(value = "showId")long showId) {
		this.entDao.deleteShowById(showId);
		return "redirect:/";
	}
}
