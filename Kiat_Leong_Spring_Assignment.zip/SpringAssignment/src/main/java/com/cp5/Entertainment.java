package com.cp5;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table
public class Entertainment {

	@Id
	@Column(name = "SHOWID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long showId;
	
	@Column(name ="SHOWNAME")
	@NotBlank(message = "Please insert a Title!")
	private String showName;
	
	@Column(name = "SHOWTYPE")
	@NotNull
	private String showType;
	
	@Column(name = "TOTALEPISODES")
	private long totalEpisodes;
	
	@Column(name = "CURRENTEPISODE")	
	private long currentEpisode;
	
	@Column(name = "STARTWATCHDATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Please insert a Start Date!")
	private LocalDate startWatchDate;
	
	@Column(name = "ENDWATCHDATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")	
	private LocalDate endWatchDate;
	
	@Column(name = "LASTWATCHEDTIMESTAMP")
	private String lastWatchedTimeStamp;
	
	@Column(name = "REMARKS")
	private String remarks;

	public long getShowId() {
		return showId;
	}

	public void setShowId(long showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getShowType() {
		return showType;
	}

	public void setShowType(String showType) {
		this.showType = showType;
	}

	public long getTotalEpisodes() {
		return totalEpisodes;
	}

	public void setTotalEpisodes(long totalEpisodes) {
		this.totalEpisodes = totalEpisodes;
	}

	public long getCurrentEpisode() {
		return currentEpisode;
	}

	public void setCurrentEpisode(long currentEpisode) {
		this.currentEpisode = currentEpisode;
	}

	public LocalDate getStartWatchDate() {
		return startWatchDate;
	}

	public void setStartWatchDate(LocalDate startWatchDate) {
		this.startWatchDate = startWatchDate;
	}

	public String getLastWatchedTimeStamp() {
		return lastWatchedTimeStamp;
	}

	public void setLastWatchedTimeStamp(String lastWatchedTimeStamp) {
		this.lastWatchedTimeStamp = lastWatchedTimeStamp;
	}

	public LocalDate getEndWatchDate() {
		return endWatchDate;
	}

	public void setEndWatchDate(LocalDate endWatchDate) {
		this.endWatchDate = endWatchDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Entertainment() {		
	}
	
	
}
