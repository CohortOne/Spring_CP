package com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

public interface EntertainmentDao {
	public List<Entertainment> getAllShows();
	public void saveShow(Entertainment entertainment);
	public void deleteShowById(long showId);
	public Entertainment getShowById(long showId);
	public Page<Entertainment> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection, String keyword);
}
