package com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class EntertainmentDaoImpl implements EntertainmentDao {

	@Autowired
	private EntertainmentRepository entRepository;
	@Override
	public List<Entertainment> getAllShows() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveShow(Entertainment entertainment) {
		entRepository.save(entertainment);
		
	}

	@Override
	public void deleteShowById(long showId) {
		entRepository.deleteById(showId);

	}

	@Override
	public Entertainment getShowById(long showId) {
		Optional<Entertainment> optional = entRepository.findById(showId);
		Entertainment entertainment = null;
		
		if (optional.isPresent())
			entertainment = optional.get();
		else
			throw new RuntimeException(" Show not found by ID :: " + showId);
		
		return entertainment;	
		
	}

	@Override
	public Page<Entertainment> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection,
			String keyword) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if (keyword!=null) {
			return entRepository.search(keyword, pageable);
		}
		return entRepository.findAll(pageable);
	}

}
