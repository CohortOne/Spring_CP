package com.cp5;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EntertainmentRepository extends JpaRepository<Entertainment, Long> {

	@Query("SELECT e FROM Entertainment e WHERE CONCAT(e.showName, ' ', e.showId, ' ', e.showType) LIKE %?1%")
	public Page<Entertainment> search(String keyword, Pageable pageable);
}
