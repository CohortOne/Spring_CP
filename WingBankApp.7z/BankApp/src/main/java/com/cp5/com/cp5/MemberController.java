package com.cp5.com.cp5;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class MemberController {

	@Autowired
	private MemberDao memberDao;

	

	@GetMapping("/showNewMemberForm")
	public String showNewMemberForm(Model model) {
		Member member = new Member();
		model.addAttribute("member", member);
		return "new_member";
		
	}
	
	@PostMapping("/saveMember")
	public String saveMember(@Valid @ModelAttribute("member") Member member, BindingResult bindingResult) {
        // save employee to database
		
		if(bindingResult.hasErrors())
			return "new_member";
		
		memberDao.saveMember(member);
		return "redirect:/";
	}

	
	
			@GetMapping("/showFormForUpdate/{memId}")
				public String showFormForUpdate(@PathVariable(value = "memId") long memId, Model model) {
					// Get Employee from the Service 
					Member member = memberDao.getMemberById(memId);
					
					// set employee as a model attribute to pre-populate the form 
					model.addAttribute("member", member);
					return "update_member";
				}
			
			@GetMapping("/deleteMember/{memId}")
			public String deleteMember(@PathVariable (value = "memId") long memId) {
			 // call delete employee method 
			 this.memberDao.deleteMemberById(memId);
			 return "redirect:/";
			}
			
			@GetMapping("/")
			public String viewHomePage(Model model) {
				//model.addAttribute("listMembers", memberDao.getAllMembers());
				return findPaginated(1, "memId", "ASC", model);
			}
			
			@GetMapping("/page/{pageNo}")
			private String findPaginated(@PathVariable(value = "pageNo") int pageNo, 
				@RequestParam("sortField") String sortField, 
				@RequestParam("sortDirection") String sortDirection, 
					Model model) {
				
				int pageSize = 5;
				Page <Member> page = memberDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
				List <Member> listMembers = page.getContent();
				model.addAttribute("listMembers", listMembers);
				model.addAttribute("totalPages", page.getTotalPages());
				model.addAttribute("totalItems", page.getTotalElements());
				model.addAttribute("currentPage", pageNo);
				model.addAttribute("sortField", sortField);
				model.addAttribute("sortDirection", sortDirection);
				model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
				return "index";
			}

}
