package com.cp5.com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

//import com.cp5.com.cp5.Member;
//import com.cp5.com.cp5.MemberRepository;

//import org.springframework.data.domain.PageRequest;
@Service
public class MemberDaoImpl implements MemberDao {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> getAllMembers() {
		return memberRepository.findAll();
	}
	
	@Override 
	public void saveMember(Member member) { 
	   memberRepository.save(member);
	  }
	
	
	@Override
	public void deleteMemberById(long memId) {
		memberRepository.deleteById(memId);
	}
 
	@Override
	public Member getMemberById(long memId) {
		
		Optional <Member> optional = memberRepository.findById(memId);
		Member member = null;
		
		if(optional.isPresent())
			member = optional.get();
		else
			throw new RuntimeException(" Member not found for id :: " + memId);
		
		return member;		
	}
	
	@Override
	public Page<Member> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo -1, pageSize, sort);
		return memberRepository.findAll(pageable);
	}

}
