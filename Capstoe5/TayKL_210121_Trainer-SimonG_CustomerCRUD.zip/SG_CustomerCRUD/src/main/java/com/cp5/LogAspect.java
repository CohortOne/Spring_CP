package com.cp5;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {
	Logger log = LoggerFactory.getLogger(LogAspect.class);
	
	@Autowired
	private CustomerDao customerDao;
	
	@Before("execution(public String deleteCustomer(..))")
	public void doLog1(JoinPoint jp) {
		Object obj = jp.getArgs()[0];
		Long l = Long.parseLong(obj.toString());
		System.out.println(l);
		Customer customer = customerDao.getCustomerById(l);
		log.info( "Deleting ... " + customer.toString() );
//		System.out.println("Deleting ... " + customer + "\n" + "Customer ID: " + l);
	}
	
	@Before("execution(public String saveCustomer(..))")
	public void doLog2(JoinPoint jp) {
		Object obj = jp.getArgs()[0];
		Customer c = (Customer) obj;
		System.out.println(c);
		if(c.getCustId() != 0) {
			Customer customer = customerDao.getCustomerById(c.getCustId());
			log.info("Updating record ... " + customer.toString());
		}else {
			log.info("Creating new record ... ");
		}
			

	}
	
	@After("execution(public String saveCustomer(..))")
	public void doLog3(JoinPoint jp) {
		Object obj = jp.getArgs()[0];
		Customer c = (Customer) obj;
		System.out.println(c);
		Customer customer = customerDao.getCustomerById(c.getCustId());
		log.info("Saving record ... " + customer.toString());
	}
	
}
