package oneBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneBankApplication.class, args);
	}

}
