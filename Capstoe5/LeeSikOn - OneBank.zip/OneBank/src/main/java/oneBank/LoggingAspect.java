package oneBank;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;
//import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Aspect
@Configuration
public class LoggingAspect {
	
	Logger logger = LoggerFactory.getLogger(OneBankApplication.class);
		
	//@Before("execution(public String getName())")
	//@Before("execution(public String com.Aop.demo.Circle.getName())")
	//@Before("allGetters()")
	//@Before("* * *(**)")
	@Before("execution(public String otsAndCust*(..))")  // .. = any number of parameters,  *. at least one parameter
	public void LoggingAdviceBand(JoinPoint joinPoint) {
		String strSignature = joinPoint.getSignature().toString();
		System.out.println("\tAdvice run. The LoggingAdviceBand Before method is called");
		System.out.println("\t\tMethod about to be executed (getSignature()) is " + strSignature);
		System.out.println("\t\tNumber of parameters passed is " + joinPoint.getArgs().length);
		if (joinPoint.getArgs().length > 0) {
			System.out.println("\t\tFirst parameter has " + joinPoint.getArgs()[0].getClass().toString());
			if (joinPoint.getArgs()[0].getClass().toString().equals("class java.lang.Long")) {
				System.out.println("\t\tFirst parameter being Long and has value of " + Long.parseLong(joinPoint.getArgs()[0].toString()));
			}
		}
		logger.info("The Advice method has been called under Annotation @Before for " + strSignature + ".");
	}

	@Before("execution(public String otsDeleCust*(..))")  // .. = any number of parameters,  *. at least one parameter
	public void LoggingAdviceBdel(JoinPoint joinPoint) {
		String strSignature = joinPoint.getSignature().toString();
		System.out.println("\tAdvice run. The LoggingAdviceBdel Before method is called");
		System.out.println("\t\tMethod about to be executed (getSignature()) is " + strSignature);
		System.out.println("\t\tNumber of parameters passed is " + joinPoint.getArgs().length);
		if (joinPoint.getArgs().length > 0) {
			System.out.println("\t\tFirst parameter has " + joinPoint.getArgs()[0].getClass().toString());
			if (joinPoint.getArgs()[0].getClass().toString().equals("class java.lang.Long")) {
				System.out.println("\t\tFirst parameter being Long and has value of " + Long.parseLong(joinPoint.getArgs()[0].toString()));
			}
		}
		logger.info("The Advice method has been called under Annotation @Before for " + strSignature + ".");
	}

	@After("execution(public * oneBank.*.*Cust*(..))")
	public void LoggingAdviceA(JoinPoint joinPoint) {
		String strSignature = joinPoint.getSignature().toString();
		System.out.println("\tAdvice run. The After method is called");
		System.out.println("\t\tMethod already executed has signature (getSignature()) is " + strSignature);
		logger.info("The Advice method has been called under Annotation @After for " + strSignature + ".");
	}

}