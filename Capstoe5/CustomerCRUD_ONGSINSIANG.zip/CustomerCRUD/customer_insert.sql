--------------------------------------------------------
--  File created - Wednesday-January-13-2021   
--------------------------------------------------------
REM INSERTING into HR.CUSTOMER
SET DEFINE OFF;
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Thor SB',to_date('08-JUL-79','DD-MON-RR'),'teset123@test.com',1,'0182372323');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Roller Coaster',to_date('22-SEP-89','DD-MON-RR'),'test123@gmail.com',0,'239283982');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Humpty Dumpty',to_date('01-JAN-99','DD-MON-RR'),'jo@test.com',1,'29389238');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Katy Porter',to_date('01-JAN-92','DD-MON-RR'),'eskja',1,'23989238');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Don Slump',to_date('01-JAN-89','DD-MON-RR'),'tanuj@ajnacs.com',1,'23982938');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Joe Biden',to_date('20-JUL-10','DD-MON-RR'),'tanish@ajnacs.com',1,'2399823');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Iron Man',to_date('08-JUL-49','DD-MON-RR'),'iron.man@mcu.com',1,'0182372323');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Steve Rogers',to_date('22-SEP-69','DD-MON-RR'),'steve@mcu.com',0,'239283982');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Ant Man',to_date('01-JAN-99','DD-MON-RR'),'jo@test.com',1,'29389238');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Wonder Woman',to_date('01-JAN-72','DD-MON-RR'),'ww84@dcu.com',1,'23989238');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Mac Pro',to_date('01-JAN-79','DD-MON-RR'),'macpro@apple.com',1,'23982938');
Insert into HR.CUSTOMER (CUST_NAME,DOB,EMAIL,IS_ACTIVE,PHONE_NO) values ('Asus Rog',to_date('20-JUL-70','DD-MON-RR'),'asusrog@asus.com',1,'2399823');