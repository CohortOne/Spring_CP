package com.cp5;

// Newly created class to do loggings for all functions
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {

	Logger log = LoggerFactory.getLogger(LogAspect.class);
	
	@Autowired
	private CustomerDao customerDao;
	
	@Before("execution(public String deleteCustomer(..))")
	public void doLog(JoinPoint jp) {
		
		Object obj = jp.getArgs()[0];
		Long l = Long.parseLong(obj.toString());
		System.out.println(l);
		Customer customer =customerDao.getCustomerById(l);
		System.out.println(customer);
	//	System.out.println("Request to delete Customer by Name " + customer + "/n" + "Customer ID : " + l);
		log.info("Request to delete Customer by the Name " +customer.toString() + " with an Customer ID of " + l +" has been received");
	}
	
}
