package com.cp5;

import java.util.List;

import org.springframework.data.domain.Page;

public interface AccountDao  {
	
	public List<Account> listAccountdetails();
	public void saveAccount(Account account);
    public Account getAccountById(long AccNo);
    public void deleteAccountById(long AccNo) ;
    public Page <Account> findPaginated(int pageNo, int pageSize,String sortField, String sortDirection);
    
}
