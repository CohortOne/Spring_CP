package com.cp5;

import java.lang.reflect.Array;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Aspect
@Component
public class LoggerAspect {

	
	Logger log = LoggerFactory.getLogger(LoggerAspect.class);
	
	@Autowired
	private AccountDao accountDao;
	
	@Before("execution(public String deleteAccount(..))")
	public void DologDelete(JoinPoint jp) {
		Object obj = jp.getArgs()[0];
		Long l = Long.parseLong(obj.toString());
		//System.out.println(l);
		Account account = accountDao.getAccountById(l);
		//System.out.println("Request to delete Account by name : "+account);
		log.info("Request to delete by Account  by Id : " +account.getAccNo() +",and Customer UIN" + account.getCustUIN());
	}

		
	@Before("execution(public String showFormForUpdate(..))")
	  public void Dolog(JoinPoint jp) {
			Object obj = jp.getArgs()[0];
			Long l = Long.parseLong(obj.toString());
			Account account = accountDao.getAccountById(l);
			log.info(" update Account details  :" +account.getAccNo() +account.toString() +", with an account id of " + l + " has been updated.");
		
	}	
	
	@After("execution(public String showFormForUpdate(..))")
	  public void Dologupdate(JoinPoint jp) {
			Object obj = jp.getArgs()[0];
			Long l = Long.parseLong(obj.toString());
			Account account = accountDao.getAccountById(l);
			log.info(" updated Account details  :" +account.getAccNo() +account.toString() +", with an account id of " + l + " has been updated.");
		
	}	
	@After("execution(public String  saveAccountInfo(..))")
	public void DologSave (JoinPoint jp) {
		Object account = jp.getArgs()[0];
		log.info("New Account Saved: "+ account);
		
	}

}
