package com.cp5;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;



@Aspect
@Component
public class LogAspect {
	
	Logger log = LoggerFactory.getLogger(LogAspect.class);

	@Autowired
	private CustomerDao customerDao;
	
	@Before("execution(public String deleteCustomer(..))")
	//@Before("execution(public String saveCustomer(..))")
	public void deleteLog(JoinPoint jp) {
		  Object obj = jp.getArgs()[0];
		  Long l = Long.parseLong(obj.toString());
		  //System.out.println(l);
		  Customer customer = customerDao.getCustomerById(l);  
		  System.out.println("Received request to delete Customer with ID " + l + " and Name is "+ customer.getCustName());
		  log.info("Received request to delete Customer with ID " + l + "and Name "+ customer.toString());
		  //log.info(customer.toString());
	}
	
	
	//@After("execution(public String showNewCustomerForm(..))")
	//public void newCustLog(JoinPoint jp) {
	//	  Object[] sigArgs = jp.getArgs();
	//	  for (Object sigArg:sigArgs) {
	//		  Customer currCust = (Customer) sigArg;
	//		  System.out.println("Requested to add a Customer  : " + currCust);
	//	  }
	//}
	
	@Before("execution(public String saveCustomer(..))")
	public void saveLog(JoinPoint jp) {
		  Object[] sigArgs = jp.getArgs();
		  for (Object sigArg:sigArgs) {
			  Customer currCust = (Customer) sigArg;
			  log.info("Created a Customer " +  currCust.toString());
			  System.out.println("Added a Customer  : " + currCust.getCustName() + " with Hand Phone Number " + currCust.getPhoneNo());
		  }
	}
	
	@Before("execution(public String updateCustomer(..))")
	public void b4updateLog(JoinPoint jp) {
		  Object[] sigArgs = jp.getArgs();
		  for (Object sigArg:sigArgs) {
			  Customer currCust = (Customer) sigArg;
			  log.info("Received request to Update Customer with ID " + "and Name "+ currCust.toString());
			  System.out.println("Received request to Update Customer Info : " + currCust);
		  }
	}
	
	@After("execution(public String updateCustomer(..))")
	public void updateLog(JoinPoint jp) {
		  Object[] sigArgs = jp.getArgs();
		  for (Object sigArg:sigArgs) {
			  Customer currCust = (Customer) sigArg;
			  log.info("Updated Customer Info " +  currCust.toString());
			  System.out.println("Updated Customer Info : " + currCust);
		  }
	}
	
	
	
	 
	
	//@Before("aspectcapture()")
	//public void SecondLogging() {
	//	System.out.println("Advice Save Customer from aspect capture."); 
	//}
	
	//@Pointcut("execution(public String saveCustomer(..))")
	//public void aspectcapture() {}
	

}
