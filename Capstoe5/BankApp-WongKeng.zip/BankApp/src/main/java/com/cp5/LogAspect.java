package com.cp5;



import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {
	
	private static final Logger logger = LoggerFactory.getLogger(LogAspect.class);
	
	@Autowired
	private CustomerDao customerDao;
	
//	@Before("execution(Customer com.cp5.CustomerDao.getCustomerById(..))")
//	public void beforeGetCustomerByIdMethod() {
//		
//		System.out.println("********");
//		System.out.println(getClass() + " ===> beforeGetCustomerByIdMethod()");
//		System.out.println("********");
//		logger.info(getClass() + " ===> beforeGetCustomerByIdMethod()");
//	}
//	
//	@Before("execution(* findPaginated(..))")
//	public void beforeFindPaginatedMethod() {
//		
//		System.out.println("********");
//		System.out.println(getClass() + " ===> beforeFindPaginatedMethod()");
//		System.out.println("********");
//		logger.info(getClass() + " ===> beforeFindPaginatedMethod()");
//	}
//	
//	@After("execution(Customer com.cp5.CustomerDao.getCustomerById(..))")
//	public void aftereGetCustomerByIdMethod() {
//		
//		System.out.println("********");
//		System.out.println(getClass() + " ===> aftereGetCustomerByIdMethod()");
//		System.out.println("********");
//		logger.info(getClass() + " ===> aftereGetCustomerByIdMethod()");
//	}
	
	@Before("execution(public String deleteCustomer(..))")
	public void deleteLog(JoinPoint jp) {
		 Object obj = jp.getArgs()[0];
		 Long lg = Long.parseLong(obj.toString());
		 
		 System.out.println(lg);
		 
		 Customer customer = customerDao.getCustomerById(lg);
		 
		 MethodSignature methodSig = (MethodSignature)(jp.getSignature());
		 
		 System.out.println("**********************************************************************");
		 System.out.println("Method: " + methodSig);
		 System.out.println(getClass() + " ===> " + customer + " DELETED");
		 System.out.println("**********************************************************************");
		 
		 logger.warn("**********************************************************************");
		 logger.warn("Method: " + methodSig);
		 logger.warn(getClass() + " ===> " + customer.toString() + " DELETED");
		 logger.warn("**********************************************************************");
	}
	
	@AfterReturning("execution(public * saveCustomer(*))")
	public void newCustLog(JoinPoint jp) {
		 Object obj = jp.getArgs()[0];
		 
		 Customer customer = (Customer)obj;
		 
		 MethodSignature methodSig = (MethodSignature)(jp.getSignature());
		 
		 System.out.println("**********************************************************************");
		 System.out.println("Method: " + methodSig);
		 System.out.println(getClass() + " ===> " + customer + " CREATED");
		 System.out.println("**********************************************************************"); 
		 
		 logger.warn("**********************************************************************");
		 logger.warn("Method: " + methodSig);
		 logger.warn(getClass() + " ===> " + customer.toString() + " CREATED");
		 logger.warn("**********************************************************************");
		 
	}
	
	@AfterReturning("execution(public * updateCustomer(*))")
	public void updateCustLog(JoinPoint jp) {
		 Object obj = jp.getArgs()[0];
		 
		 Customer customer = (Customer)obj;
		 
		 MethodSignature methodSig = (MethodSignature)(jp.getSignature());
		 
		 System.out.println("**********************************************************************");
		 System.out.println("Method: " + methodSig);
		 System.out.println(getClass() + " ===> " + customer + " UPDATED");
		 System.out.println("**********************************************************************");
		 
		 logger.warn("*****************************************************************************");
		 logger.warn("Method: " + methodSig);
		 logger.warn(getClass() + " ===> " + customer.toString() + " UPDATED");
		 logger.warn("*****************************************************************************");
	}
	
	

}
