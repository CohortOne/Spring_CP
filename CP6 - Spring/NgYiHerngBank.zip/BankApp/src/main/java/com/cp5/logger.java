package com.cp5;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Aspect
@Component
public class logger {
	Logger log = LoggerFactory.getLogger(logger.class);
	
	
	@Autowired
	private CustomerDao customerDao;
	
	@Before("execution(public String deleteCustomer(..))")
	public void Capturelog(JoinPoint jp) {
		Object obj = jp.getArgs()[0];
		Long l =Long.parseLong(obj.toString());
		System.out.println(1);
		Customer customer= customerDao.getCustomerById(1);
		System.out.println("request delete" +customer);
		log.info(customer.toString());
	}
	@After("execution(public String showFormForUpdate(..))")
	public void beforeUpdatelog(JoinPoint jp) {
	Object obj = jp.getArgs()[0];
	Long custId =Long.parseLong(obj.toString());
	Customer customer = customerDao.getCustomerById(custId);
	log.info("customer"+ custId+ "" + customer.toString() +"updating");		
	}
	@After("execution(public String saveCustomer(..))")
	public void saveLog(JoinPoint jp) {
		Object customer = jp.getArgs()[0];
		log.info("customer"+ customer.toString()+ "info save");
	}
}
