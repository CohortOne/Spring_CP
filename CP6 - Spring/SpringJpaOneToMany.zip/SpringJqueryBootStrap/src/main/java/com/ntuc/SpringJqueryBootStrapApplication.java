package com.ntuc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJqueryBootStrapApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJqueryBootStrapApplication.class, args);
	}

}
