package com.example.googledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoogledemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
