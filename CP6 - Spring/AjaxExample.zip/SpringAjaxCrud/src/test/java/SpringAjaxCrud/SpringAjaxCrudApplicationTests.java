package SpringAjaxCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAjaxCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
