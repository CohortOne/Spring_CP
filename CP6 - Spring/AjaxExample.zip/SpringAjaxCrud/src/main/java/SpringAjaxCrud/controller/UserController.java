package SpringAjaxCrud.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import SpringAjaxCrud.dao.UserRepository;
import SpringAjaxCrud.entity.AjaxUser;
import SpringAjaxCrud.entity.MyResponse;

@RestController
public class UserController {
	@Autowired
	private UserRepository repository;

	@PostMapping("/addUser")
	public ResponseEntity<Object> addUser(@RequestBody AjaxUser ajaxUser) {
		repository.save(ajaxUser);
		MyResponse<AjaxUser> response = new MyResponse<>("success", ajaxUser);
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

	@GetMapping("/getUsers")
	public ResponseEntity<Object> getUsers() {
		MyResponse<List<AjaxUser>> response = new MyResponse<>("success", repository.findAll());
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

}
