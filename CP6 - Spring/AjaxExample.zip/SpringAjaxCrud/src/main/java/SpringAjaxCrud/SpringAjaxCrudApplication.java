package SpringAjaxCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAjaxCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAjaxCrudApplication.class, args);
	}

}
