package SpringAjaxCrud.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import SpringAjaxCrud.entity.AjaxUser;

public interface UserRepository extends JpaRepository<AjaxUser, Integer>{

}
