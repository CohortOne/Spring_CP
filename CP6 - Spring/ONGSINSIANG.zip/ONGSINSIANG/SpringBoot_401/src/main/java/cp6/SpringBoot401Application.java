package cp6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot401Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot401Application.class, args);
	}

}
