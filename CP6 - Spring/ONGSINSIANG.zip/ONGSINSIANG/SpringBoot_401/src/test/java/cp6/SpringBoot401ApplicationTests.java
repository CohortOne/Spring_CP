package cp6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot401ApplicationTests {

	@Test
	void contextLoads() {
	}

}
