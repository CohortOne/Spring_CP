package com.ntuc.model;

public enum Color {

    RED,
    WHITE,
    BLACK
}
