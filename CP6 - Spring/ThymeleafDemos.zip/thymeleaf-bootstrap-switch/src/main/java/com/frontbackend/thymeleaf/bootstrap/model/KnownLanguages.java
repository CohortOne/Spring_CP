package com.frontbackend.thymeleaf.bootstrap.model;

public class KnownLanguages {

    private boolean java;
    private boolean css;
    private boolean angular;
    private boolean react;
    private boolean python;
    private boolean go;
	public boolean isJava() {
		return java;
	}
	public void setJava(boolean java) {
		this.java = java;
	}
	public boolean isCss() {
		return css;
	}
	public void setCss(boolean css) {
		this.css = css;
	}
	public boolean isAngular() {
		return angular;
	}
	public void setAngular(boolean angular) {
		this.angular = angular;
	}
	public boolean isReact() {
		return react;
	}
	public void setReact(boolean react) {
		this.react = react;
	}
	public boolean isPython() {
		return python;
	}
	public void setPython(boolean python) {
		this.python = python;
	}
	public boolean isGo() {
		return go;
	}
	public void setGo(boolean go) {
		this.go = go;
	}
	public KnownLanguages() {
		super();
	}
    
    

}
