package com.ntuc.model.paging;

public enum PageItemType {

    DOTS,
    PAGE

}
