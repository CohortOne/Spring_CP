package com.ntuc.model;

public class ProgrammingSkills {

    private int java;
    private int css;
    private int angular;
    private int react;
    private int python;
    private int go;
	public int getJava() {
		return java;
	}
	public void setJava(int java) {
		this.java = java;
	}
	public int getCss() {
		return css;
	}
	public void setCss(int css) {
		this.css = css;
	}
	public int getAngular() {
		return angular;
	}
	public void setAngular(int angular) {
		this.angular = angular;
	}
	public int getReact() {
		return react;
	}
	public void setReact(int react) {
		this.react = react;
	}
	public int getPython() {
		return python;
	}
	public void setPython(int python) {
		this.python = python;
	}
	public int getGo() {
		return go;
	}
	public void setGo(int go) {
		this.go = go;
	}
    
    

}
