package com.ntuc.employee.model;

public enum EmployeePosition {

    MANAGER,
    DIRECTOR,
    CHIEF,
    SUPERVISOR

}
