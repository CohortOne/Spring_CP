package NiceSprAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NiceSprAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
