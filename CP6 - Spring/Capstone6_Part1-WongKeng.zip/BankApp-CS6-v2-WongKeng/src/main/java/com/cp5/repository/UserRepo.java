package com.cp5.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.cp5.MyUsers;
import com.cp5.Users;

@Repository
public interface UserRepo extends JpaRepository<Users, Long> {
	Users findByUsername(String username);
}
