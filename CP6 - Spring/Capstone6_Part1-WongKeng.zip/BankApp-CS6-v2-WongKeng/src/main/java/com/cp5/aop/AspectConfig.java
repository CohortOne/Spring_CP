package com.cp5.aop;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
//@ComponentScan("com.cp5")
//@ComponentScan({"com.cp5", "daoauthenticate"})
public class AspectConfig {

}
