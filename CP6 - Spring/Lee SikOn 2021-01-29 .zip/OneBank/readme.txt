Project utilized these Spring Boot features:

1. security, so that users are created, with encrypted password, and multi-roles, which are validated in the application.
2. Use of request attributes (Model model.get/setAttributes)
3. Use of session attributes (Session session.get/setAttributes)
4. Use of session attributes to simplify the .html pages while maintaining session persistenance.



2021-01-29 add @EnableJdbcHttpSession
to have session attributes and save to db.
