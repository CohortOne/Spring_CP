package oneBank;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BankuserController {

	@Autowired
	private BankuserDao bankuserDao;

	private Object principal;
	private String username;
	private String[] roles;

	
	private boolean hasRole(String role) {

		System.out.println("\n\t Explicit authentication begins...");
		principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		username = "";
		roles = new String[] {};
		
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
			System.out.println("\t Authentication: User=" + username);
//			roles = SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream().toArray(String[]::new);
			System.out.println("\t authenticaed user has these roles=" + ((UserDetails) principal).getAuthorities());
			if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
	          .anyMatch(r -> r.getAuthority().equals(role))) {
				System.out.println("\t Explicit authentication ends with true.");
				return true;}
			Bankuser user = bankuserDao.getBankuserByUsername(username);
			System.out.println("\t User has auth=" + user.getAuth());
			if (user.getAuth().equals(role)) {
				System.out.println("\t Explicit authentication ends with true.");
				return true;} else {
					System.out.println("\t Explicit authentication ends with false.");
					return false;
				}
		} else {
			System.out.println("\t Explicit authentication ends with false due to missing UserDetails.");
			return false;
		}
	}

	
	@RequestMapping("/")
	public String Welcome(Model model, HttpSession session) {
		int currPage = 1;
		int totalPages = 1;
		int pageSize = 5;
		int nextPageSize = 10;
		session.setAttribute("currPage", currPage);
		session.setAttribute("totalPages", totalPages);
		session.setAttribute("pageSize", pageSize);
		session.setAttribute("nextPageSize", nextPageSize);
		String sortField = "userId";
		session.setAttribute("sortField", sortField);
		String sortDirection = "ASC";
		session.setAttribute("sortDirection", sortDirection);
		if (hasRole("ADMIN")) {
				session.setAttribute("username", username);
				return "redirect:/admBank";}
		if (hasRole("USER")) {
			session.setAttribute("username", username);
				return "redirect:/oneBank";}
		return "redirect:/login";
	}


	@RequestMapping("/login")
	public String login() {
		System.out.println("\tlogin detected...");
			return "login";
	}

	
	@RequestMapping("/bye")
	public String bye(Model model) {
		model.addAttribute("optMsg", "You are logged out.");
		return "login";
	}
	
	
	@GetMapping("/admBank") //this is the home page at root directory of the website to be triggered by a http GET. 
	public String viewHomePage(Model model, HttpSession session) {
		if (!hasRole("ADMIN")) {
			return "/403";}
		return userPaginated(0, model, session);
	}

	
	@GetMapping("/pageUser/{pageMvnt}")
	public String userPaginated(@PathVariable(value="pageMvnt") int pageMvnt,
			Model model, 
			HttpSession session) {
		if (!hasRole("ADMIN")) {
			return "/403";}

		int currPage = (int) session.getAttribute("currPage");
		int totalPages = (int) session.getAttribute("totalPages"); 
		int pageSize = (int) session.getAttribute("pageSize"); 
		String sortField = (String) session.getAttribute("sortField"); 
		String sortDirection = (String) session.getAttribute("sortDirection");

		switch (pageMvnt) {
		    case -9: currPage = 1; break;                            // go to first page
		    case -1: currPage = currPage > 1? currPage - 1:1; break; // go to prev page  
		    case  0: break;                                          // stay at curr page
		    case  1: currPage = currPage < totalPages? totalPages + 1:totalPages; break;  // go to next page
		    case  9: currPage = totalPages; break;                   // go to last page
		    default: currPage = 1;
		}
		
		Bankuser newUser = (Bankuser)model.getAttribute("newUser");
		if (newUser==null) {
			newUser = new Bankuser();
			newUser.setIsActive(true);
		}
		model.addAttribute("newUser", newUser);
		session.setAttribute("currPage", currPage);
		Page <Bankuser> page = bankuserDao.userPaginated(currPage, pageSize, sortField, sortDirection);
		session.setAttribute("totalPages", page.getTotalPages());
		if ((currPage > 1) && (currPage > page.getTotalPages())) {return userPaginated(9, model, session);}
		List <Bankuser> listUsers = page.getContent();
		model.addAttribute("listUsers", listUsers);
		session.setAttribute("totalItems", page.getTotalElements());
		return "Bankusers";
	}
	

	@GetMapping("/pageUserSort/{sortField}")
	public String userPageSort(@PathVariable(value="sortField") String newSortField, 
			Model model, 
			HttpSession session) {
		if (!hasRole("ADMIN")) {
			return "/403";}
		
		int currPage = (int) session.getAttribute("currPage"); 
		int totalPages = (int) session.getAttribute("totalPages"); 
		String sortField = (String)session.getAttribute("sortField");
		String sortDirection = (String) session.getAttribute("sortDirection");
		if (newSortField.equals(sortField)) {
			currPage = totalPages - currPage + 1;
			sortDirection = sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC";
		} else {
			currPage = 1;  // go to page 1 if sortField is changed
			sortField = newSortField;
		}
		
		session.setAttribute("currPage", currPage);
		session.setAttribute("sortField", sortField);
		session.setAttribute("sortDirection", sortDirection);
		return userPaginated(0, model, session);
	}


	@GetMapping("/pageUserSize/{newPageSize}")
	public String userPageSize(@PathVariable(value="newPageSize") int newPageSize, 
			Model model, 
			HttpSession session) {
		if (!hasRole("ADMIN")) {
			return "/403";}

		int pageNo = (int) session.getAttribute("currPage");
		int pageSize = (int) session.getAttribute("pageSize"); 
		pageNo = (((pageNo - 1) * pageSize + 1) / newPageSize) + (((((pageNo - 1) * pageSize + 1) % newPageSize)==0)?0:1);
		int nextPageSize = pageSize;
		pageSize = newPageSize; 
		session.setAttribute("currPage", pageNo);
		session.setAttribute("pageSize", pageSize);
		session.setAttribute("nextPageSize", nextPageSize);
		return userPaginated(9, model, session);
	}

	
	@GetMapping("/otsBankuserUpdate/{userId}")
	public String otsBankuserUpdate(@PathVariable(value = "userId") long userId, 
			Model model, 
			HttpSession session) {

		if (!hasRole("ADMIN")) {
			return "/403";}

		// Get customer from the Service
		Bankuser newUser = new Bankuser();
		if (userId == 0) {
			newUser.setIsActive(true);  // this method is not expected to be invoked with userId=0
		} else {
			if (userId > 0) {
				newUser = bankuserDao.getBankuserById(userId);
				if (newUser.getUsername().equalsIgnoreCase(username)) {
					newUser = new Bankuser();
					model.addAttribute("optMsg", "You are not allowed to modify your own user record.");
				} else {
					model.addAttribute("optMsg", "Modify user record and then click <Save>.");
				}
			} else {
				Bankuser user = bankuserDao.getBankuserById(-userId);
				newUser = new Bankuser();
				newUser.setPassword(user.getPassword());
				newUser.setAuth(user.getAuth());
				newUser.setIsActive(user.getIsActive());
				newUser.setPswdExpiry(user.getPswdExpiry());
				newUser.setUserExpiry(user.getUserExpiry());
				newUser.setRoles(user.getRoles());  // this is useless because the roles will not persist after going to html page.
				model.addAttribute("optMsg", "Enter required details and then click <Save>.");
			}
		}
		model.addAttribute("newUser", newUser);
		return userPaginated(0, model, session);
	}

	
	@PostMapping("/saveBankuserOTS")	
	public String saveBankuserOTS(@Valid @ModelAttribute("newUser")Bankuser newUser, BindingResult bindingResult, 
			Model model, 
			HttpSession session) {

		if (!hasRole("ADMIN")) {
			return "/403";}

		if (!bindingResult.hasErrors()) {
			if (newUser.getUsername().equalsIgnoreCase(username)) {
				model.addAttribute("optMsg", "You cannot save a user with your own username.");
			} else {
				Bankuser tmpUser = bankuserDao.getBankuserByUsername(newUser.getUsername());
				if (tmpUser!=null) {
					if (newUser.getUserId()==tmpUser.getUserId()) {
						bankuserDao.saveBankuser(newUser);
						newUser = new Bankuser();
						model.addAttribute("newUser", newUser);
					} else {
						model.addAttribute("optMsg", "A user with the username [" + newUser.getUsername() + "] already exists.");
					}
				} else {
					bankuserDao.saveBankuser(newUser);
					newUser = new Bankuser();
					model.addAttribute("newUser", newUser);
				}
			}
			return userPaginated(0, model, session); 
		} else {
			model.addAttribute("optMsg", "Please correct the validation errors.");
		}
		model.addAttribute("newUser", newUser);
		return userPaginated(0, model, session);
	}
	

	@GetMapping("/otsDeleBankuser/{userId}")
	public String otsDeleBankuser(@PathVariable(value = "userId") long userId,
			Model model, 
			HttpSession session) {
		if (!hasRole("ADMIN")) {
			return "/403";}

		// call delete customer method 
		Bankuser newUser = bankuserDao.getBankuserById(userId);
		if (newUser.getUsername().equalsIgnoreCase(username)) {
			model.addAttribute("optMsg", "You should not delete your own user record.");
		} else {
			this.bankuserDao.deleteBankuserById(userId);
		}
		return userPaginated(0, model, session);
	}

}
