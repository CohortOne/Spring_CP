package oneBank;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

@Component
public interface BankuserDao {

	public List<Bankuser> getAllBankusers();
	public void saveBankuser(Bankuser bankuser);
	public Bankuser getBankuserById(long userId);
	public Bankuser getBankuserByUsername(String username);
	public void deleteBankuserById(long userId);
	public Page<Bankuser> userPaginated(int pageNo, int pageSize, String sortField, String sortDirection); 

}


