package oneBank;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service  //
public class BankuserDaoImpl implements BankuserDao {

	@Autowired
	private BankuserRepository userRepository;
	
	@Override
	public List<Bankuser> getAllBankusers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public void saveBankuser(Bankuser user) {
		userRepository.save(user);
		
	}

	@Override
	public Bankuser getBankuserById(long userId) {
		Optional <Bankuser> optional = userRepository.findById(userId);
		Bankuser user = null;
		if (optional.isPresent())
			user = optional.get();
		else
			throw new RuntimeException("User not found for id=" + userId);
		return user;
	}

	@Override
	public void deleteBankuserById(long userId) {
		userRepository.deleteById(userId);
		
	}

	@Override
	public Page<Bankuser> userPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort); // Note pageNo starts from 0, not 1, hence the -1.
		return userRepository.findAll(pageable);
	}

	@Override
	public Bankuser getBankuserByUsername(String username) {
		Bankuser user = userRepository.findByUsername(username);
		return user;
	}

}
