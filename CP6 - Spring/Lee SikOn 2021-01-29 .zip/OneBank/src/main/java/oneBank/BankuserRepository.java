package oneBank;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankuserRepository extends JpaRepository<Bankuser, Long> {
	Bankuser findByUsername(String username);
}
