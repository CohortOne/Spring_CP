package oneBank;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
public class Bankuser implements Serializable{

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)  // defines how this id is to be generated....??
		@Column(name="USERID")  // The following attribute is linked to this column in the db table
		private long userId;

		@Column(name = "USERNAME")  
		@Size (min = 4, max = 8)
		@NotNull
		private String username;

		@NotNull
		private String password;

		@NotNull
		private String auth;

		@Column(name = "ISACTIVE") 
		private boolean isActive;

		@NotNull
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate userExpiry;

		@NotNull
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate pswdExpiry;

		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

		public String getAuth() {
			return auth;
		}
		
		public void setAuth(String auth) {
			this.auth = auth;
		}
		
		public boolean getIsActive() {
			return isActive;
		}
		public void setIsActive(boolean isActive) {
			this.isActive = isActive;
		}
		public LocalDate getUserExpiry() {
			return userExpiry;
		}
		public void setUserExpiry(LocalDate userExpiry) {
			this.userExpiry = userExpiry;
		}
		public LocalDate getPswdExpiry() {
			return pswdExpiry;
		}
		public void setPswdExpiry(LocalDate pswdExpiry) {
			this.pswdExpiry = pswdExpiry;
		}
		@Override
		public String toString() {
			return "Bankuser [userId=" + userId + ", username=" + username + ", isActive=" + isActive
					+ ", userExpiry=" + userExpiry + ", pswdExpiry=" + pswdExpiry + "]";
		}

		@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
		@JoinTable(
				name = "users_roles",     // there will be a table by this name
				joinColumns = @JoinColumn(name = "userid"),            // joining table Bankuser and Role by this and the next column names
				inverseJoinColumns = @JoinColumn(name = "roleid")
				)
		private Set<Role> roles = new HashSet<>(); 

		public Set<Role> getRoles() {
			return roles;
		}

		public void setRoles(Set<Role> roles) {
			this.roles = roles;
		}

}
