package oneBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.session.jdbc.config.annotation.web.http.EnableJdbcHttpSession;

@EnableJdbcHttpSession
@SpringBootApplication
public class OneBankApplication {

	public static void main(String[] args) {
		System.out.println("\toneBank application starting...");
		SpringApplication.run(OneBankApplication.class, args);
	}

}
