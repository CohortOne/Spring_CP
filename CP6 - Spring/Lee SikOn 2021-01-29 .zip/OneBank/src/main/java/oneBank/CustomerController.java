package oneBank;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerController {

	@Autowired
	private BankuserDao bankuserDao;
	
	@Autowired
	private CustomerDao customerDao;

	private Object principal;
	private String username;
	private String[] roles;

	
	private boolean hasRole(String role) {

		System.out.println("\n\t Explicit authentication begins...");
		principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		username = "";
		roles = new String[] {};
		
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
			System.out.println("\t Authentication: User=" + username);
//			roles = SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream().toArray(String[]::new);
			System.out.println("\t authenticaed user has these roles=" + ((UserDetails) principal).getAuthorities());
			if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
	          .anyMatch(r -> r.getAuthority().equals(role))) {
				System.out.println("\t Explicit authentication ends with true.");
				return true;}
			Bankuser user = bankuserDao.getBankuserByUsername(username);
			System.out.println("\t User has auth=" + user.getAuth());
			if (user.getAuth().equals(role)) {
				System.out.println("\t Explicit authentication ends with true.");
				return true;} else {
					System.out.println("\t Explicit authentication ends with false.");
					return false;
				}
		} else {
			System.out.println("\t Explicit authentication ends with false due to missing UserDetails.");
			return false;
		}
	}

//	@GetMapping("/") //this is the home page at root directory of the website to be triggered by a http GET. 
	@GetMapping("/oneBank") //this is the home page at root directory of the website to be triggered by a http GET. 
	public String viewHomePage(Model model) {
		return findPaginated(1, 5, "custId", "ASC", 0, model);
	}

	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable(value="pageNo") int pageNo, 
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {
		if (!hasRole("USER")) {
			return "/403";}
		Customer newCust = (Customer)model.getAttribute("newCust");
		if (newCust==null) {
			newCust = new Customer();
			newCust.setIsActive(true);
			newCust.setDateUpd(java.time.LocalDate.now());
		}
		model.addAttribute("newCust", newCust);
		model.addAttribute("currPage", pageNo);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		Page <Customer> page = customerDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		if ((pageNo > 1) && (pageNo > page.getTotalPages())) {return findPaginated(page.getTotalPages(), pageSize, sortField, sortDirection, pinCustId, model);}
		List <Customer> listCustomers = page.getContent();
		model.addAttribute("listCustomers", listCustomers);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC");
		Customer pinCust = new Customer();
		if (pinCustId>0) {
			pinCust = customerDao.getCustomerById(pinCustId);
			if (pinCust==null) {
				pinCustId = 0;
			}
		}
		model.addAttribute("pinCust", pinCust);
		return "Customers";
	}
	
	@GetMapping("/otsCustomerUpdate/{custId}")
	public String otsCustomerUpdate(@PathVariable(value = "custId") long custId, 
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
            Model model) {

		if (!hasRole("USER")) {
			return "/403";}
		// Get customer from the Service
		Customer newCust = new Customer();
		if (custId == 0) {
			newCust.setIsActive(true);
		} else {
			if (custId > 0) {
				newCust = customerDao.getCustomerById(custId);
			} else {
				// the following won't work if you do this:
				// newCust = customerDao.getCustomerById(-custId);
				// newCust.setCustId(0);
				// newCust.setNric("");
				// newCust.setPassCode("");
				// because setters will also affect the customer object in listCustomers
				Customer customer = customerDao.getCustomerById(-custId);
				newCust = new Customer();
				newCust.setCustName(customer.getCustName());
				newCust.setPhoneNo(customer.getPhoneNo());
				newCust.setEmail(customer.getEmail());
				newCust.setAddr1(customer.getAddr1());
				newCust.setAddr2(customer.getAddr2());
				newCust.setDob(customer.getDob());
				newCust.setIsActive(customer.getIsActive());
			}
		}
		newCust.setDateUpd(java.time.LocalDate.now());
		model.addAttribute("newCust", newCust);
		return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model);
	}

	@PostMapping("/saveCustomerOTS")	
	public String saveCustomerOTS(@Valid @ModelAttribute("newCust")Customer newCust, BindingResult bindingResult, 
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {

		if (!hasRole("USER")) {
			return "/403";}
//		int pageSize = (int)model.getAttribute("pageSize"); 
//		String sortField = (String)model.getAttribute("sortField");
//		String sortDirection = (String)model.getAttribute("sortDirection");
//		int currPage = (int)model.getAttribute("currPage");

		if (!bindingResult.hasErrors()) {
			customerDao.saveCustomer(newCust);
			newCust = new Customer();
			model.addAttribute("newCust", newCust);
			return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model); 
		}
		model.addAttribute("newCust", newCust);
		return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model);
	}
	
	@GetMapping("/showCustomerForUpdate/{custId}")
	public String showCustomerForUpdate(@PathVariable(value = "custId") long custId, 
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {

		if (!hasRole("USER")) {
			return "/403";}
		// Get customer from the Service
		Customer newCust = new Customer();
		if (custId == 0) {
			newCust.setIsActive(true);
			model.addAttribute("updMode", "New");
		} else {
			if (custId > 0) {
				newCust = customerDao.getCustomerById(custId);
				model.addAttribute("updMode", "Update");
			} else {
				newCust = customerDao.getCustomerById(-custId);
				newCust.setCustId(0);
				newCust.setNric("");
				newCust.setPassCode("");
				model.addAttribute("updMode", "Duplicate");
			}
		}
		newCust.setDateUpd(java.time.LocalDate.now());
		model.addAttribute("newCust", newCust);
		model.addAttribute("currPage", currPage);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("pinCustId", pinCustId);
		return "upd_customer";
	}
	
	
	@PostMapping("/saveCustomer")	
	public String saveCustomer(@Valid @ModelAttribute("newCust")Customer newCust, BindingResult bindingResult, 
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("updMode") String updMode, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {
		if (!hasRole("USER")) {
			return "/403";}
		model.addAttribute("currPage", currPage);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("pinCustId", pinCustId);
		if (bindingResult.hasErrors()) {
			model.addAttribute("updMode", updMode);
			return ("upd_customer");
			}
		customerDao.saveCustomer(newCust);
		model.addAttribute("newCust", null);
		return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model);
	}
	
	
	@GetMapping("/otsDeleCustomer/{custId}")
	public String otsDeleCustomer(@PathVariable(value = "custId") long custId,
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {
		if (!hasRole("USER")) {
			return "/403";}
		// call delete customer method 
        this.customerDao.deleteCustomerById(custId);
        if (custId==pinCustId) {pinCustId = 0;}
		return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model);
	}

	@GetMapping("/otsAndCustomer/{custId}")
	public String otsAndCustomer(@PathVariable(value = "custId") long custId,
			@RequestParam("pageSize") int pageSize, 
			@RequestParam("sortField") String sortField, 
			@RequestParam("sortDirection") String sortDirection, 
			@RequestParam("currPage") int currPage,
			@RequestParam("pinCustId") int pinCustId, 
			Model model) {
		if (!hasRole("USER")) {
			return "/403";}
		// call update customer method
		Boolean activate = custId > 0; // +ve customer id to activate, -ve to deactivate
		if (!activate) custId = - custId;
		Customer customer = customerDao.getCustomerById(custId);
		customer.setIsActive(activate);
		customer.setDateUpd(java.time.LocalDate.now());
		this.customerDao.saveCustomer(customer);
		return findPaginated(currPage, pageSize, sortField, sortDirection, pinCustId, model);
	}
	
}
