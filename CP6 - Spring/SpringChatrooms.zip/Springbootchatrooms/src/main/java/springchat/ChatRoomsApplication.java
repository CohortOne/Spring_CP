package springchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatRoomsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatRoomsApplication.class, args);
	}
}
