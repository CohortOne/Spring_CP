package springchat;

public class Constants {

	public static final String USER_LEFT = "Left!";
	public static final String NEW_USER_JOINED = "Joined!";

}
