package com.cp5;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class AccountDaoImpl implements AccountDao {
	
	@Autowired
	private AccountRepository accountRepository;

	@Override
	public List<Account> listAccountdetails() {
		List<Account> list = accountRepository.findAll();
		return list;
	}

	@Override
	public Account getAccountById(long accNo) {
		Optional <Account> optional = accountRepository.findById(accNo);
		Account account = null;
		if(optional.isPresent())
			account = optional.get();
		else
			throw new RuntimeException(" Account not found for id :: " + accNo);
		
		return account;		

	}

	@Override
	public void deleteAccountById(long accNo) {
		accountRepository.deleteById(accNo);
		
	}

	
	@Override
	public Page<Account> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				:Sort.by(sortField).descending();
		PageRequest pageble = PageRequest.of(pageNo - 1, pageSize, sort);
		return accountRepository.findAll(pageble);
	}

	@Override
	public void saveAccount(Account account) {
		accountRepository.save(account);
		
	}

}
