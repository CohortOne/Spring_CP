package com.cp5;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import java.security.Principal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {

	@Autowired
	private AccountDao accountDao;

	@GetMapping("/")  
	public String viewHomePage(Model model, HttpSession session) {
		model.addAttribute("listAccount",accountDao.listAccountdetails());
	    session.setAttribute("accType", "Savings");
		session.setAttribute("Lucky", "Admin");
		return findPaginated(1, "accNo", "ASC", model);

	}

	@GetMapping("/page/{pageNo}")
    public String findPaginated(@PathVariable(value = "pageNo") int pageNo,
    		                                            @RequestParam("sortField") String sortField, 
    		                                            @RequestParam("sortDirection") String sortDirection, 
    		                                                     Model model) {

		int pageSize = 5;
		Page <Account> page = accountDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List<Account> listAccount = page.getContent();
		model.addAttribute("listAccount", listAccount);	
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		//System.out.println(model.getAttribute("reverseSortDirection"));
		return "index";
	}
	

	@GetMapping("/showNewAccountRegistrationForm")
	public String showNewAccountRegistrationForm(Model model) {
		Account account = new Account();
		model.addAttribute("account", account);
		return "NewAccountRegistration";
	}
	@PostMapping("/saveAccount")
	public String saveAccountInfo(@Valid @ModelAttribute("account")Account account, BindingResult bindingResult ) {
		//System.out.println("In Save Account");
		//System.out.println(account.getAccBal());
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
			return "NewAccountRegistration";
		}
		System.out.println(account);
		accountDao.saveAccount(account);
		return "redirect:/";
	}



	@GetMapping("/showFormForUpdate/{accNo}")
	public String showFormForUpdate(@PathVariable(value="accNo") long accNo, Model model) {
		Account account =  accountDao.getAccountById(accNo);
		model.addAttribute("account", account);
		return "UpdateAccount";
	}
	@GetMapping("/deleteAccount/{accNo}")
	public String deleteAccount(@PathVariable (value = "accNo") long accNo) {
		this.accountDao.deleteAccountById(accNo);;
		return "redirect:/";
	}
	

	@RequestMapping("/testaop")
	public String TestAop(Principal principal) {
		return "Welcomeaop";
	}

	@RequestMapping("/login")
	public String login() {
			return "login";
	}

	@RequestMapping("/logout-success")
	public String logout() {
			return "logout";

	}
	
	
}
